<?php
class Notification{
    protected $name;
    protected $type;
    protected $status;
    protected $creation_time;

    public static $number_of_users = 0;

    function __construct($name, $type, $status= 'disabled')
    {
        $this->name = $name;
        $this->type = $type ;
        $this->status = $status;

        self::$number_of_users++;
        date_default_timezone_set('America/Toronto');
        $this->creation_time = date('Y-m-d H:i:s');
    }

    function __get($name){
        return $this->$name;
    }

    function __set($name, $value){
        switch($name){
            case "name":
                $this->name = $name;
                break;
            case "type":
                $this->type = $type;
                break;
            case "status":
                $this->status = $status;
                break;
            default :
                echo $name . "Attribute not found or it cannot be set!";
        }
    }

    function __toString(){
        return "This is an object of type " . get_class($this). "<br>";
    }
}
