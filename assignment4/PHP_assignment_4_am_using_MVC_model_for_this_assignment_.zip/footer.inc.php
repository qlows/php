<script src=https://my.gblearn.com/js/loadscript.js></script>

</body>
</html>